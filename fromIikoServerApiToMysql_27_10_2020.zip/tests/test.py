import config

print(config.base_path)