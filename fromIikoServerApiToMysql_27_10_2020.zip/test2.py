import json

f = open("olap.json")

olap = json.load(f)
print(olap)